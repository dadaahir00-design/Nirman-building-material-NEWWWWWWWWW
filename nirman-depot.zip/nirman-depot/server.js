// Nirman Material Depot: a small static web server with no dependencies.
// Serves everything in ./public and answers /healthz for Render's health check.
const http = require("http");
const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

const PORT = process.env.PORT || 3000;
const ROOT = path.join(__dirname, "public");

const TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".txt": "text/plain; charset=utf-8",
};

const server = http.createServer((req, res) => {
  const url = new URL(req.url, "http://localhost");

  if (url.pathname === "/healthz") {
    res.writeHead(200, { "Content-Type": "text/plain" });
    return res.end("ok");
  }
  if (req.method !== "GET" && req.method !== "HEAD") {
    res.writeHead(405, { Allow: "GET, HEAD" });
    return res.end();
  }

  let rel;
  try {
    rel = decodeURIComponent(url.pathname);
  } catch (e) {
    res.writeHead(400);
    return res.end("Bad request");
  }
  if (rel.endsWith("/")) rel += "index.html";

  // Block path traversal: the resolved file must stay inside ./public.
  const file = path.normalize(path.join(ROOT, rel));
  if (!file.startsWith(ROOT + path.sep)) {
    res.writeHead(403);
    return res.end("Forbidden");
  }

  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      return res.end("Not found");
    }
    const ext = path.extname(file).toLowerCase();
    const type = TYPES[ext] || "application/octet-stream";
    const isImage = ext === ".jpg" || ext === ".jpeg" || ext === ".png" || ext === ".webp";
    const headers = {
      "Content-Type": type,
      // HTML is always re-checked so a new deploy shows up at once; images are cached for a week.
      "Cache-Control": isImage ? "public, max-age=604800" : "no-cache",
      "X-Content-Type-Options": "nosniff",
    };

    const compressible = ext === ".html" || ext === ".css" || ext === ".js" || ext === ".json" || ext === ".svg";
    const wantsGzip = /\bgzip\b/.test(req.headers["accept-encoding"] || "");

    if (req.method === "HEAD") {
      res.writeHead(200, headers);
      return res.end();
    }
    const stream = fs.createReadStream(file);
    stream.on("error", () => {
      if (!res.headersSent) res.writeHead(500);
      res.end();
    });
    if (compressible && wantsGzip) {
      res.writeHead(200, { ...headers, "Content-Encoding": "gzip", Vary: "Accept-Encoding" });
      stream.pipe(zlib.createGzip()).pipe(res);
    } else {
      res.writeHead(200, { ...headers, "Content-Length": st.size });
      stream.pipe(res);
    }
  });
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Nirman Material Depot running on port ${PORT}`);
});
