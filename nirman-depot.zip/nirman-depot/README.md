# Nirman Material Depot

An online store for building materials. It is one web page plus a tiny Node server, so anyone can open it on any phone or computer at the same time.

```
nirman-depot/
  public/
    index.html      the whole store (design, products, cart)
    images/         one JPG per product, named after its SKU
  server.js         serves ./public, no packages to install
  package.json
  render.yaml       Render settings
```

## Run it on your computer

Needs Node 18 or newer.

```
npm start
```

Open http://localhost:3000

## Put it online with Render

1. Create a free GitHub account if you don't have one, then make a new repository.
2. Upload everything in this folder to that repository (on GitHub: Add file, Upload files).
3. Sign up at https://render.com and choose New, then Web Service.
4. Connect your GitHub repository.
5. Use these settings (Render fills most of them in from `render.yaml`):
   - Runtime: Node
   - Build command: `npm install`
   - Start command: `npm start`
   - Instance type: Free
6. Click Create Web Service. After a minute or two Render gives you a link like `https://nirman-material-depot.onrender.com`. Share that link.

The free plan goes to sleep after about 15 minutes with no visitors, so the first visit after a quiet spell takes up to a minute to load. A paid instance stays awake.

## Change your products and prices

Open `public/index.html` and find the list that starts with `var P = [`. Each line is one product:

```
{ id: "CEM-53", cat: "Cement", name: "OPC 53 Grade Cement", spec: "50 kg bag, ISI marked. Beams, columns, slabs.", unit: "bag", price: 395, step: 10, min: 10 },
```

- `id` is the product code. The photo is `public/images/<id>.jpg`.
- `price` is per `unit`, in rupees, GST included.
- `min` is the smallest order, `step` is how much the plus and minus buttons change it.

Delivery rules are near the top of the script: `FREE_ABOVE` and `DELIVERY`.

## Use your own photos

The images that come with this project are drawings made for the demo, not photographs of real stock. To use real photos, save each one as a JPG named after the product code (for example `CEM-53.jpg`) and replace the file in `public/images/`. A size of 640 x 400 pixels works well, and keeping each file under 150 KB keeps the page fast on mobile data. If a photo file is missing, the page shows a simple pattern instead.

## How orders work today

The cart is saved on each visitor's own device. When a customer finishes, the page gives them an order summary to copy and send to you (WhatsApp, SMS or call). Nothing is stored on the server and no payment is taken. Receiving orders directly in a dashboard and taking online payment both need a database and a payment provider, which can be added later.
